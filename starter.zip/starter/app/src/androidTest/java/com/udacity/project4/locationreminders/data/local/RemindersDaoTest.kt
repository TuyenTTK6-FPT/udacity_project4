package com.udacity.project4.locationreminders.data.local

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider.getApplicationContext
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.filters.SmallTest;
import com.udacity.project4.locationreminders.data.dto.ReminderDTO

import org.junit.Before;
import org.junit.Rule;
import org.junit.runner.RunWith;

import kotlinx.coroutines.ExperimentalCoroutinesApi;
import kotlinx.coroutines.test.runBlockingTest
import org.hamcrest.CoreMatchers.`is`
import org.hamcrest.CoreMatchers.notNullValue
import org.hamcrest.MatcherAssert.assertThat
import org.junit.After
import org.junit.Test

@ExperimentalCoroutinesApi
@RunWith(AndroidJUnit4::class)
//UT DAO
@SmallTest
class RemindersDaoTest {

    private lateinit var database: RemindersDatabase

    @get:Rule
    var instantExecutorRule = InstantTaskExecutorRule()

    @Before
    fun initDb() {
        database = Room.inMemoryDatabaseBuilder(
            getApplicationContext(),
            RemindersDatabase::class.java
        ).build()
    }

    @After
    fun closeDb() = database.close()
    private fun getReminder(): ReminderDTO {
        return ReminderDTO(
            title = "title",
            description = "description",
            location = "location",
            latitude = 40.440124,
            longitude = 134.3241267
        )
    }

    @Test
    fun insertReminderAndFindById() = runBlockingTest {
        val reminder = getReminder()
        database.reminderDao().saveReminder(reminder)
        val loading = database.reminderDao().getReminderById(reminder.id)
        assertThat<ReminderDTO>(loading as ReminderDTO, notNullValue())
        assertThat(loading.id, `is`(reminder.id))
        assertThat(loading.title, `is`(reminder.title))
        assertThat(loading.description, `is`(reminder.description))
        assertThat(loading.latitude, `is`(reminder.latitude))
        assertThat(loading.longitude, `is`(reminder.longitude))
        assertThat(loading.location, `is`(reminder.location))
    }
}
