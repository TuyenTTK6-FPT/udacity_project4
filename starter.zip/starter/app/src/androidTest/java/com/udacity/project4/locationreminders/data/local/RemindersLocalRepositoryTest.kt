package com.udacity.project4.locationreminders.data.local

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.MediumTest
import com.udacity.project4.locationreminders.data.dto.ReminderDTO
import com.udacity.project4.locationreminders.data.dto.Result
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.runBlocking
import org.hamcrest.CoreMatchers.`is`
import org.hamcrest.MatcherAssert.assertThat
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith


@ExperimentalCoroutinesApi
@RunWith(AndroidJUnit4::class)
@MediumTest
class RemindersLocalRepositoryTest {
    private lateinit var database: RemindersDatabase
    private lateinit var repository: RemindersLocalRepository

    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    private fun getReminder(): ReminderDTO {
        return ReminderDTO(
            title = "title",
            description = "description",
            location = "location",
            latitude = 40.440124,
            longitude = 134.3241267
        )
    }

    @Before
    fun setup() {
        database = Room.inMemoryDatabaseBuilder(
            ApplicationProvider.getApplicationContext(),
            RemindersDatabase::class.java
        ).allowMainThreadQueries().build()

        repository = RemindersLocalRepository(database.reminderDao(), Dispatchers.Main)
    }

    @After
    fun cleanUp() {
        database.close()
    }

    @Test
    fun saveReminder_retrievesReminder() = runBlocking {
        val reminder = getReminder()
        repository.saveReminder(reminder)
        val success = repository.getReminder(reminder.id)

        assertThat(success is Result.success, `is`(true))
        success as Result.Success

        assertThat(success.data.title, `is`(reminder.title))
        assertThat(success.data.description, `is`(reminder.description))
        assertThat(success.data.latitude, `is`(reminder.latitude))
        assertThat(success.data.longitude, `is`(reminder.longitude))
        assertThat(success.data.location, `is`(reminder.location))
    }

    @Test
    fun deleteAllReminders_getReminderById() = runBlocking {
        val reminder = getReminder()
        repository.saveReminder(reminder)
        repository.deleteAllReminders()
        val success = repository.getReminder(reminder.id)
        assertThat(success is Result.Error, `is`(true))
        success as Result.Error
        assertThat(success.message.message, `is`("Invalid Reminder not found"))

    }
}