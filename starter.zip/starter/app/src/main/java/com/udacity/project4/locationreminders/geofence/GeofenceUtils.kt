package com.udacity.project4.locationreminders.geofence

/*
TuyenTTK6_Geofence
 */
internal object GeofenceConstants {
    const val GEOFENCE_RADIUS_IN_METER = 600f
    const val ACTION_GEOFENCE_EVENT = "ACTION_GEOFENCE_EVENT"
}