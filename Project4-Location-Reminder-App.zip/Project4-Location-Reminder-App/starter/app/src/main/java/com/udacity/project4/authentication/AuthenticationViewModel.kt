package com.udacity.project4.authentication

import androidx.lifecycle.ViewModel
import androidx.lifecycle.map

class AuthenticationViewModel : ViewModel() {

    enum class AuthenticationState {
        AUTHENTICATED, UN_AUTHENTICATED, INVALID_AUTHENTICATION
    }

    // TODO Create the authenticationState variable based on the FirebaseUserLiveData object.when creating this variable, other classes will be able to query whether the user is logged in or not?
    val authenticationState = FirebaseUserLiveData().map { user ->
        if (user != null) {
            AuthenticationState.AUTHENTICATED
        } else {
            AuthenticationState.UN_AUTHENTICATED
        }
    }


}