package com.udacity.project4.authentication

import androidx.lifecycle.LiveData
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser

/**
 * This class observes the current FirebaseUser. If there is no login in user, FirebaseUser will be null. onActive() and onInactive() will get trigger when the configuration change
 *  May be undesirable/expensive depending on the but is Ok for this purpose since we are only add and remove the authStateListener.
 */
class FirebaseUserLiveData : LiveData<FirebaseUser?>() {
    private val firebaseAuth = FirebaseAuth.getInstance()

    // TODO set the value of this FireUserLiveData object You can utilize the FirebaseAuth.AuthStateListener callback to get update on current Firebase user login into app
    private val authStateListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
        value = firebaseAuth.currentUser
        // TODO FirebaseAuth instance instantiated at the beginning of the class to get a entry into the Firebase Authentication SDK the app is using. With an instance of the FirebaseAuth class
    }

    // Start observer the FirebaseAuth state to see if there is current a login in user.
    override fun onActive() {
        firebaseAuth.addAuthStateListener(authStateListener)
    }

    // When this object no longer has an active observer, stop observing the FirebaseAuth state to
    // prevent memory leaks.
    override fun onInactive() {
        firebaseAuth.removeAuthStateListener(authStateListener)
    }
}